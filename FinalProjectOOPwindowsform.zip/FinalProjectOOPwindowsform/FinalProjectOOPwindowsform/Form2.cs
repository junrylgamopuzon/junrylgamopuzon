﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using System.Windows.Forms;
using FinalProjectOOPwindowsform.Model;
using Microsoft.VisualBasic;

namespace FinalProjectOOPwindowsform
{
    public partial class Form2 : Form
    {
        private readonly HttpClient client = new HttpClient { BaseAddress = new Uri("http://localhost:5118/api/") };

        public Form2()
        {
            InitializeComponent();
        }

        // Form load event
        private async void Form2_Load(object sender, EventArgs e)
        {
            await LoadProductsAsync(); // Load products when the form loads
        }

        // Method to load all products
        private async Task LoadProductsAsync()
        {
            try
            {
                var products = await client.GetFromJsonAsync<List<Product>>("Product");
                dataGridViewProducts.DataSource = products;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to load products. Error: {ex.Message}");
            }
        }

        // Add Product
        private async void btnAdd_Click(object sender, EventArgs e)
        {
            string name = Interaction.InputBox("Enter product name:", "Add Product", "");
            if (string.IsNullOrWhiteSpace(name)) return;

            string priceStr = Interaction.InputBox("Enter product price:", "Add Product", "");
            if (!decimal.TryParse(priceStr, out decimal price)) return;

            string quantityStr = Interaction.InputBox("Enter product quantity:", "Add Product", "");
            if (!int.TryParse(quantityStr, out int quantity)) return;

            var product = new Product
            {
                Name = name,
                Price = price,
                Quantity = quantity
            };

            try
            {
                var response = await client.PostAsJsonAsync("Product", product);
                if (response.IsSuccessStatusCode)
                {
                    MessageBox.Show("Product added successfully.");
                    await LoadProductsAsync();
                }
                else
                {
                    MessageBox.Show("Failed to add product.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to add product. Error: {ex.Message}");
            }
        }

        // Update Product
        private async void btnUpdate_Click(object sender, EventArgs e)
        {
            if (dataGridViewProducts.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a product to update.");
                return;
            }

            int id = (int)dataGridViewProducts.SelectedRows[0].Cells["Id"].Value;
            string currentName = dataGridViewProducts.SelectedRows[0].Cells["Name"].Value.ToString();
            string currentPrice = dataGridViewProducts.SelectedRows[0].Cells["Price"].Value.ToString();
            string currentQuantity = dataGridViewProducts.SelectedRows[0].Cells["Quantity"].Value.ToString();

            string name = Interaction.InputBox("Enter new product name:", "Update Product", currentName);
            if (string.IsNullOrWhiteSpace(name)) return;

            string priceStr = Interaction.InputBox("Enter new product price:", "Update Product", currentPrice);
            if (!decimal.TryParse(priceStr, out decimal price)) return;

            string quantityStr = Interaction.InputBox("Enter new product quantity:", "Update Product", currentQuantity);
            if (!int.TryParse(quantityStr, out int quantity)) return;

            var product = new Product
            {
                Id = id,
                Name = name,
                Price = price,
                Quantity = quantity
            };

            try
            {
                var response = await client.PutAsJsonAsync($"Product/{id}", product); // Ensure correct endpoint
                if (response.IsSuccessStatusCode)
                {
                    MessageBox.Show("Product updated successfully.");
                    await LoadProductsAsync();
                }
                else
                {
                    MessageBox.Show("Failed to update product.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to update product. Error: {ex.Message}");
            }
        }

        // Delete Product
        private async void btnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridViewProducts.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a product to delete.");
                return;
            }

            int id = (int)dataGridViewProducts.SelectedRows[0].Cells["Id"].Value;
            var confirmResult = MessageBox.Show("Are you sure you want to delete this product?", "Delete Product", MessageBoxButtons.YesNo);
            if (confirmResult == DialogResult.Yes)
            {
                try
                {
                    var response = await client.DeleteAsync($"Product/{id}"); // Ensure correct endpoint
                    if (response.IsSuccessStatusCode)
                    {
                        MessageBox.Show("Product deleted successfully.");
                        await LoadProductsAsync();
                    }
                    else
                    {
                        MessageBox.Show("Failed to delete product.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Failed to delete product. Error: {ex.Message}");
                }
            }
        }

        // Get Products (Refresh)
        private async void btnGet_Click(object sender, EventArgs e)
        {
            await LoadProductsAsync();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.Show();
            this.Hide();
        }
    }
}
